# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['caipy', 'main', 'utilities']

package_data = \
{'': ['*']}

install_requires = \
['jupyter>=1.0.0,<2.0.0',
 'matplotlib>=3.8.1,<4.0.0',
 'numpy>=1.26.1,<2.0.0',
 'pandas>=2.1.2,<3.0.0',
 'scikit_learn>=1.3.2,<2.0.0',
 'scipy>=1.11.3,<2.0.0',
 'tqdm>=4.66.1,<5.0.0']

entry_points = \
{'console_scripts': ['ok = _init_:check_dependencies',
                     'test = utilities.pointless:start',
                     'test1 = src.main._init_:check_dependencies']}

setup_kwargs = {
    'name': 'caipy',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'SanjanaYasna',
    'author_email': 'sanyasna517@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<3.13',
}


setup(**setup_kwargs)

#!/usr/bin/python
import subprocess

#checks meta_data, calls clean function, returns variables and dictionary for fold values per variable
#will do set intersection to print possible values, NEED TO TEST
def check_meta_format(meta, meta_path):
    var_to_run = [col for col in meta.columns if (col not in ['pkey', 'Sample Name', 'Sample_Name']) and ('Folds' not in col)]
    all_var = ', '.join(var_to_run)
    all_folds_per_var = dict() #equivalent to all_folds
    for var in var_to_run:
        if f'{var}_Folds' in meta.columns:
            print(f'{var}_Folds')
            #NEED TO IMPLEMENT: add to all_folds_per_var
        else:
            #runs entire stratification script, since user liekly doesn't have any fold columns.
            #NOTE: should this instead be done one-by-one in the loop by a stratify_column function? (for some reason, missing a fold column for only certain variables?)
            print('bad format, missing fold column for sample variable ' +  var + ' . Running stratification script on ENTIRE metadata file')
            #NEED TO IMPLEMENT: output resulting meta_path, and then run this function again...
            subprocess.run(["python", "stratify_samples.py", "-m", meta_path])
            break
        #add uniue folds to dict for var, and filter out df for any -1 values in folds
    meta = clean_meta_for_negatives(meta, var_to_run)
    return var_to_run, all_var, meta

#NEED TO TEST. drops rows with -1 for the fold columns
def clean_meta_for_negatives(meta, var_to_run):
    for var in var_to_run:
        meta = meta.drop(meta[meta[f'{var}_Folds'] == -1].index, inplace  = True)
    return meta

#Possible implementation:
#def stratify_column(meta):

# check format of input .csv filename
def check_csv(filename):
    if filename[-4:] != '.csv':
        filename = filename + '.csv'
    return filename  
from _init_ import *
from model_tools import *
check_dependencies()

# THOUGHT: it's a pain to verify that a test_fold number is valid (exists) and you have to consider what fold values there actually are 
# (and that you aren't assigning numbers that don't exist if for whatever reason folds skip a number)  
# PERHAPS ask user for fold value range (it's 1 to what number n?) and take them for their word
# Maybe if allowed, later have the stratification script run regarldess and only take in a normal meta file (or overwrite existing fold values)
# REGRESSION STUFF
method_dict = {
    0:['OLS','OMP','LASSO','Ridge','ElasticNet','PLS','PCR-lin','PCR-py','SVR-lin','SVR-py','RF','GBR','kNN'],
    1:['OLS'],
    2:['OMP'],
    3:['LASSO'],
    4:['Ridge'],
    5:['ElasticNet'],
    6:['PLS'],
    7:['PCR-lin'],
    8:['PCR-py'],
    9:['SVR-lin'],
    10:['SVR-py'],
    11:['RF'],
    12:['GBR'],
    13:['kNN']
}

# PROMPTS
method_prompt = '''Do you want to run:
    [0] *ALL MODELS*
    [1] Ordinary Least Squares (OLS)
    [2] Orthogonal Matching Pursuit (OMP)
    [3] the Least Absolute Shrinkage and Selection Operator (LASSO)
    [4] Ridge regression
    [5] ElasticNet
    [6] Partial Least Squares (PLS)
    [7] Principal Components Regression with linear PCA kernel (PCR-lin)
    [8] Principal Components Regression with 2nd degree polynomial PCA kernel (PCR-py)
    [9] Support Vector Regression with linear kernel (SVR-lin)
    [10] Support Vector Regression with 2nd degree polynomial kernel (SVR-py)
    [11] Random Forest regressor (RF)
    [12] Gradient Boosting regressor (GBR)
    [13] k-Nearest Neighbors regressor (kNN)
...or a combination, separated by a space or comma?: '''
std_prompt = 'Should all variables follow the same modelling procedure? (set test fold, model type(s)) (y/n): '
test_prompt = 'Do you want to use one of the folds as a test set? Otherwise all data used for training (y/n): '
test_prompt2 = 'Which fold should be the test fold? '

#POSSIBLE ARGUMENTS 
parser = argparse.ArgumentParser()
parser.add_argument('-f', '--datafolder', type=str, default=None, help='Path of folder with data')
parser.add_argument('-o', '--outpath', type=str, default=None, help='Path of folder to output results')
parser.add_argument('-s', '--spectra_name', type=str, default=None, help='Spectra filename')
parser.add_argument('-m', '--meta_name', type=str, default=None, help='Metadata filename')
parser.add_argument('-std', '--standard', type=bool, default=None, help='Follow a standard procedure for each variable (bool)')
parser.add_argument('-dt', '--do_test', type=bool, default=None, help='Hold a fold out as test data (bool)')
parser.add_argument('-mt', '--method', type=str, default=None, help=f'Number corresponding to method selection from: {method_prompt}')
parser.add_argument('-tf', '--test_fold', type=int, default=None, help='Integer of fold to be used for testing')
parser.add_argument('-hp', '--hide_progress', type=bool, default=None, help='Hides progress bars')
parser.add_argument('-mc', '--max_components', type=int, default=None, help='Sets the maximum PLS components')
parser.add_argument('-np', '--num_params', type=int, default=None, help='Sets the number of values to test for LASSO, Ridge, ElasticNet, SVR')
parser.add_argument('-pd', '--poly_deg', type=int, default=None, help='Sets the polynomial degree for SVR and kernel PCR')
parser.add_argument('-mn', '--max_neighbors', type=int, default=None, help='Sets the maximum number of neighbors for kNN')

args=parser.parse_args()
data_folder = args.datafolder
if data_folder is not None:
    data_folder = data_folder.replace("'","")
outpath = args.outpath
if outpath is not None:
    outpath = outpath.replace("'","")
spectra_path = args.spectra_name
if spectra_path is not None:
    spectra_path = spectra_path.replace("'","")
meta_path = args.meta_name
if meta_path is not None:
    meta_path = meta_path.replace("'","")
standard = args.standard
do_test = args.do_test
method_type = args.method
if method_type is not None:
    method_type = method_type.replace("'","")
test_fold = args.test_fold
hide_progress = args.hide_progress
max_components_ = args.max_components
num_params_ = args.num_params
poly_deg_ = args.poly_deg
max_neighbors_ = args.max_neighbors

#set spectra, meta data frames, from directories. If arguments below not specified, they are asked for
meta, spectra, meta_path, spectra_path = directories(data_folder, outpath, spectra_path, meta_path) 
print(data_folder)
if data_folder is not None:
    meta_path = os.path.join(data_folder, meta_path)
#checks meta file format, cleans it, 
var_to_run, all_var, meta = check_meta_format(meta, meta_path)
print('Identified variable(s) to model:', all_var)
#generic run:
#  C:/Users/arifu/AppData/Local/Microsoft/WindowsApps/python3.10.exe c:/Users/arifu/Winternship/caipy/caipy2.0/main.py -f C:\Users\arifu\Winternship\caipy\test_data -o C:\Users\arifu\Winternship\caipy\test_data -s one_spectra.csv -m one_meta.csv

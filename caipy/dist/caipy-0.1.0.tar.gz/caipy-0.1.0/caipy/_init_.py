# Class that initializes many variables, plan to be called by main.py function

import argparse
import importlib.util
from importlib.metadata import version
import os
from distutils.version import StrictVersion
import sys
import pandas as pd
#gets current pwd of this file and appends requirements.txt to get full location of requirements
__location__ = os.path.realpath(os.path.join(os.getcwd(), os.path.dirname(__file__)))
#indicates missing dependencies and old software. Should it install such dependencies automatically?
def check_dependencies():
    flag = False
    print(str(__location__ ))
    with open( os.path.join(__location__, 'requirements.txt') ,'r', encoding='utf-8') as packages:
        for package in packages:
            requirement, version_min = package.split("==")
            if importlib.util.find_spec(requirement) is None:
                print(requirement + " package not installed. Please install latest version prior to running this program, or check your path")
                flag = True
            elif (StrictVersion(version(requirement)) < version_min):
                print("Install " + requirement + " to minimum version of " + version_min)
                flag = True
    # UNCOMMENT LATER ON
    # if flag:
    #     sys.exit("Please install/update such software")

#---------------------------
# INPUTS
#---------------------------

#get input directory, output directory, from user if not set from main arguments
                #return meta, spectra dataframes
def directories(data_folder, outpath, spectra_path, meta_path):
    if data_folder is None:
        data_folder, all_files = get_data_folder()
    else:
        all_files = os.listdir(data_folder)
    if outpath is None:
        outpath = get_out_folder()
    # read in data
    if spectra_path is None:
        spectra_path = get_spectra_path(data_folder, all_files)
        while 'spectra' not in spectra_path.lower():
            print('word "spectra" missing from file name. Please make sure right file is supplied, and rename said file for your own sake')
            spectra_path = get_spectra_path(data_folder, all_files)
        spectra = pd.read_csv(spectra_path)
    else:
        spectra = pd.read_csv(os.path.join(data_folder, spectra_path))
        
    if meta_path is None:
        meta_path = get_meta_path(data_folder, all_files)
        while 'meta' not in meta_path.lower():
            print('word "meta" missing from file name. Please make sure right file is supplied, and rename said file for your own sake')
            meta_path = get_meta_path(data_folder, all_files)
        meta = pd.read_csv(meta_path)
    else:
        meta = pd.read_csv(os.path.join(data_folder, meta_path))
    return meta, spectra, meta_path, spectra_path

#input file directory
def get_data_folder():
    in_prompt = 'Folder path containing data: '
    data_folder = input(in_prompt)
    while not os.path.exists(data_folder):
        print(f'Error: path {data_folder} does not exist\n')
        data_folder = input(in_prompt)
    all_files = os.listdir(data_folder)
    return data_folder, all_files

#output file directory
def get_out_folder():
    out_prompt = 'Folder path to export results: '
    outpath = input(out_prompt)
    while not os.path.exists(outpath):
        print(f'Error: path {outpath} does not exist\n')
        outpath = input(out_prompt)
    return outpath

# get user-input spectra path
def get_spectra_path(data_folder, all_files):
    spectra_prompt = 'Spectra filename: '
    spectra_file = check_csv(input(spectra_prompt))
    while spectra_file not in all_files:
        print(f'Error: file {spectra_file} not in data folder\n')
        spectra_file = check_csv(input(spectra_prompt))
    spectra_path = os.path.join(data_folder, spectra_file)
    return spectra_path

# get user-input metadata path
def get_meta_path(data_folder, all_files):
    meta_prompt = 'Metadata filename: '
    meta_file = check_csv(input(meta_prompt))
    while meta_file not in all_files:
        print(f'Error: file {meta_file} not in data folder\n')
        meta_file = check_csv(input(meta_prompt))
    meta_path = os.path.join(data_folder, meta_file)
    return meta_path

# check format of input .csv filename
def check_csv(filename):
    if filename[-4:] != '.csv':
        filename = filename + '.csv'

    return filename  

def start():
    print("reached start()")